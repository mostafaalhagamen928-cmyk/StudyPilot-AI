# StudyPilot AI — Vanguard v7 Human-First Edition

This competition build introduces a **Human Judgment Boundary** for educational AI.

## What changed for Vanguard Open 2026

- The assistant may recommend study priorities, time allocation, revision schedules, and explain changing study indicators.
- The assistant refuses high-impact personal judgments about intelligence, worth, capability, or future potential.
- Protected queries are intercepted locally and redirected toward changeable evidence and human decision-making.
- The UI clearly distinguishes **AI recommendation** from **human judgment**.
- A visible Vanguard Open 2026 banner and Human Judgment Boundary panel demonstrate the design choice.

## Competition development note

StudyPilot AI existed before The Vanguard Open 2026. This Human-First edition is a substantial competition-specific development focused on defining what educational AI should automate and what it should refuse to automate.

## Privacy

The demonstrated assistant logic runs locally inside the application and does not require cloud transmission of study data.
